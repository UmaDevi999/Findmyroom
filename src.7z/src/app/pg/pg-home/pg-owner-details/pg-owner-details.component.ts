import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pg-owner-details',
  templateUrl: './pg-owner-details.component.html',
  styleUrls: ['./pg-owner-details.component.css']
})
export class PgOwnerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
