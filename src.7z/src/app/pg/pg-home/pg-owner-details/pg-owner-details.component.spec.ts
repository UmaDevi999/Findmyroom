import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PgOwnerDetailsComponent } from './pg-owner-details.component';

describe('PgOwnerDetailsComponent', () => {
  let component: PgOwnerDetailsComponent;
  let fixture: ComponentFixture<PgOwnerDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PgOwnerDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PgOwnerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
