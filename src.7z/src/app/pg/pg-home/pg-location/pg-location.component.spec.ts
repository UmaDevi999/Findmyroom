import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PgLocationComponent } from './pg-location.component';

describe('PgLocationComponent', () => {
  let component: PgLocationComponent;
  let fixture: ComponentFixture<PgLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PgLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PgLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
