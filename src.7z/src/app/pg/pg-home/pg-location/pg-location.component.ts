import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";

@Component({
  selector: 'app-pg-location',
  templateUrl: './pg-location.component.html',
  styleUrls: ['./pg-location.component.css']
 // providers:[PropertyService]
})
export class PgLocationComponent implements OnInit {

  constructor(private propertyservice: PropertyService,private router :Router) { }
  
    ngOnInit() {
    }
    submitForm(form : NgForm)
    {
    
    
    this.router.navigateByUrl('/pg-home/pg-property-details');
   // this.router.navigate(['/','rent-home','rent-property-details',{nform : form}]);
     // console.log(form.value.city);
      console.log(this.propertyservice.pgproperty.location);
    };

}
