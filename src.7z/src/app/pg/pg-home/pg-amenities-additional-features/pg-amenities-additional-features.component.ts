import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";

@Component({
  selector: 'app-pg-amenities-additional-features',
  templateUrl: './pg-amenities-additional-features.component.html',
  styleUrls: ['./pg-amenities-additional-features.component.css']
})
export class PgAmenitiesAdditionalFeaturesComponent implements OnInit {

  constructor(public propertyservice:PropertyService, private router : Router) { }
  
    ngOnInit() {
    }
    
    submitForm(form : NgForm)
    {
    
    this.router.navigateByUrl('pg-home/pg-pricing');
      
    };
    backForm(form : NgForm)
    {
    
    this.router.navigateByUrl('pg-home/pg-property-details');
      
    };
}
