import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PgAmenitiesAdditionalFeaturesComponent } from './pg-amenities-additional-features.component';

describe('PgAmenitiesAdditionalFeaturesComponent', () => {
  let component: PgAmenitiesAdditionalFeaturesComponent;
  let fixture: ComponentFixture<PgAmenitiesAdditionalFeaturesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PgAmenitiesAdditionalFeaturesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PgAmenitiesAdditionalFeaturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
