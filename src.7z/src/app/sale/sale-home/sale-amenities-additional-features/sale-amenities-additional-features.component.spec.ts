import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleAmenitiesAdditionalFeaturesComponent } from './sale-amenities-additional-features.component';

describe('SaleAmenitiesAdditionalFeaturesComponent', () => {
  let component: SaleAmenitiesAdditionalFeaturesComponent;
  let fixture: ComponentFixture<SaleAmenitiesAdditionalFeaturesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaleAmenitiesAdditionalFeaturesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleAmenitiesAdditionalFeaturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
