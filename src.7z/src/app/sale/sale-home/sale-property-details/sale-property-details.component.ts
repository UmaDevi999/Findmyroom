import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";

@Component({
  selector: 'app-sale-property-details',
  templateUrl: './sale-property-details.component.html',
  styleUrls: ['./sale-property-details.component.css']
})
export class SalePropertyDetailsComponent implements OnInit {

  constructor(public propertyservice: PropertyService,private router:Router) { }

  ngOnInit() {
  }
  submitForm(form : NgForm)
  { 
      console.log(this.propertyservice.pgproperty.location);
      console.log(this.propertyservice.pgproperty.Flat_type);    

      this.propertyservice.pgproperty.Address = this.propertyservice.streetAdd1 + ',' + this.propertyservice.streetAdd2 + ',' + this.propertyservice.postalcode;

      console.log(this.propertyservice.pgproperty.Address);
  this.router.navigateByUrl('sale-home/sale-amenities-additional-features');    
  };

  backForm(form : NgForm)
  { 

  this.router.navigateByUrl('sale-home/sale-location');    
  };

  resetform(form : NgForm)
  {
        if(form! =null)
          form.reset();
        this.propertyservice.streetAdd1="";
        this.propertyservice.streetAdd2="";
        this.propertyservice.postalcode="";
        this.propertyservice.pgproperty.Property_description="";
        this.propertyservice.pgproperty.Built_up_area=0;   
  }

}
