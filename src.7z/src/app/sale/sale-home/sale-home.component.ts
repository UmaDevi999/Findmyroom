import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";

@Component({
  selector: 'app-sale-home',
  templateUrl: './sale-home.component.html',
  styleUrls: ['./sale-home.component.css'],
  providers : []
})
export class SaleHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
