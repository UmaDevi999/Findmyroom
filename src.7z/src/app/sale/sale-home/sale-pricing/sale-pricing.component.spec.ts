import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalePricingComponent } from './sale-pricing.component';

describe('SalePricingComponent', () => {
  let component: SalePricingComponent;
  let fixture: ComponentFixture<SalePricingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalePricingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalePricingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
