import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaleLocationComponent } from './sale-location.component';

describe('SaleLocationComponent', () => {
  let component: SaleLocationComponent;
  let fixture: ComponentFixture<SaleLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaleLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaleLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
