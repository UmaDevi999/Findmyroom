import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RentHomeComponent } from "src/app/rent/rent-home/rent-home.component";
import { SaleHomeComponent } from "src/app/sale/sale-home/sale-home.component";
import { PgHomeComponent } from "src/app/pg/pg-home/pg-home.component";
import { PgOwnerDetailsComponent } from "src/app/pg/pg-home/pg-owner-details/pg-owner-details.component";
import { PgPricingComponent } from "src/app/pg/pg-home/pg-pricing/pg-pricing.component";
import { PgAmenitiesAdditionalFeaturesComponent } from "src/app/pg/pg-home/pg-amenities-additional-features/pg-amenities-additional-features.component";
import { PgPropertyDetailsComponent } from "src/app/pg/pg-home/pg-property-details/pg-property-details.component";
import { PgLocationComponent } from "src/app/pg/pg-home/pg-location/pg-location.component";
import { SaleOwnerDetailsComponent } from "src/app/sale/sale-home/sale-owner-details/sale-owner-details.component";
import { SalePricingComponent } from "src/app/sale/sale-home/sale-pricing/sale-pricing.component";
import { SaleAmenitiesAdditionalFeaturesComponent } from "src/app/sale/sale-home/sale-amenities-additional-features/sale-amenities-additional-features.component";
import { SalePropertyDetailsComponent } from "src/app/sale/sale-home/sale-property-details/sale-property-details.component";
import { SaleLocationComponent } from "src/app/sale/sale-home/sale-location/sale-location.component";
import { RentOwnerDetailsComponent } from "src/app/rent/rent-home/rent-owner-details/rent-owner-details.component";
import { RentPricingComponent } from "src/app/rent/rent-home/rent-pricing/rent-pricing.component";
import { RentAmenitiesAdditionalFeaturesComponent } from "src/app/rent/rent-home/rent-amenities-additional-features/rent-amenities-additional-features.component";
import { RentPropertyDetailsComponent } from "src/app/rent/rent-home/rent-property-details/rent-property-details.component";
import { RentLocationComponent } from "src/app/rent/rent-home/rent-location/rent-location.component";

const routes: Routes = [
  
  {path:'rent-home',component:RentHomeComponent,
  children:[
    {path:'rent-location',component:RentLocationComponent},
    {path:'rent-property-details',component:RentPropertyDetailsComponent},
    {path:'rent-amenities-additional-features',component:RentAmenitiesAdditionalFeaturesComponent},
    {path:'rent-pricing',component:RentPricingComponent},
    {path:'rent-owner-details',component:RentOwnerDetailsComponent},
  ]},
{path:'sale-home',component:SaleHomeComponent,
children:[
{path:'sale-location',component:SaleLocationComponent},
{path:'sale-property-details',component:SalePropertyDetailsComponent},
{path:'sale-amenities-additional-features',component:SaleAmenitiesAdditionalFeaturesComponent},
{path:'sale-pricing',component:SalePricingComponent},
{path:'sale-owner-details',component:SaleOwnerDetailsComponent},
]},
{path:'pg-home',component:PgHomeComponent,
children:[
  {path:'pg-location',component:PgLocationComponent},
  {path:'pg-property-details',component:PgPropertyDetailsComponent},
  {path:'pg-amenities-additional-features',component:PgAmenitiesAdditionalFeaturesComponent},
  {path:'pg-pricing',component:PgPricingComponent},
  {path:'pg-owner-details',component:PgOwnerDetailsComponent},
]
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
