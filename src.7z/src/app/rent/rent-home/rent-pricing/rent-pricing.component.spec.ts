import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentPricingComponent } from './rent-pricing.component';

describe('RentPricingComponent', () => {
  let component: RentPricingComponent;
  let fixture: ComponentFixture<RentPricingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentPricingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentPricingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
