import { Component, OnInit } from '@angular/core';
import { FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { PropertyService } from "src/app/property.service";

@Component({
  selector: 'app-rent-pricing',
  templateUrl: './rent-pricing.component.html',
  styleUrls: ['./rent-pricing.component.css']
})
export class RentPricingComponent implements OnInit {

  //public rateControl=new FormControl("",[Validators.max(4000), Validators.min(2000)]);
  result:string;

  constructor( public propertyservice:PropertyService ,private router : Router) { 
  
  }

  ngOnInit() {
    console.log(this.propertyservice.pgproperty)
    console.log(this.propertyservice.pgproperty[0].Advance);
  }
  submitForm(form : NgForm)
  {
    this.propertyservice.pgproperty.Type="Rent";
    console.log(this.propertyservice.pgproperty.AC);
    console.log(this.propertyservice.pgproperty.additionalTextArea);
    console.log(this.propertyservice.pgproperty.Advance);
    console.log(this.propertyservice.pgproperty.AvailableFor);
    console.log(this.propertyservice.pgproperty.Bed);
    console.log(this.propertyservice.pgproperty.Built_up_area);
    console.log(this.propertyservice.pgproperty.Community_hall);
    console.log(this.propertyservice.pgproperty.Construction_Age);
    console.log(this.propertyservice.pgproperty.location);
    console.log(this.propertyservice.pgproperty.Flat_type);
    console.log(this.propertyservice.pgproperty.Sofa);
    console.log(this.propertyservice.pgproperty.Bachelor_friendly);
    console.log(this.propertyservice.pgproperty.water_source);
    console.log(this.propertyservice.pgproperty.Deal_type);
    console.log(this.propertyservice.pgproperty.Flooring);
    console.log(this.propertyservice.pgproperty.Gas_conn);
    console.log(this.propertyservice.pgproperty.Lift);
    console.log(this.propertyservice.pgproperty.no_of_floors);
    console.log(this.propertyservice.pgproperty.Occupancy);
    console.log(this.propertyservice.pgproperty.Parking);
    console.log(this.propertyservice.pgproperty.Possesion_ready);
    console.log(this.propertyservice.pgproperty.Address);
   // console.log(this.propertyservice.pgproperty.Property_description);
    console.log(this.propertyservice.pgproperty.Refridgerator);
    console.log(this.propertyservice.pgproperty.swimming_pool);
    console.log(this.propertyservice.pgproperty.TV);
    console.log(this.propertyservice.pgproperty.Price);
    console.log(this.propertyservice.pgproperty.Type);
    console.log(this.propertyservice.propId);
    
    if(this.propertyservice.propId==null)
      {
        this.propertyservice.PostProperty(this.propertyservice.pgproperty)
        .subscribe(data =>{
          this.result=data.toString();
          console.log(data);
        });
        this.router.navigateByUrl('rent-home');
      }
      else
        {
          this.propertyservice.PutProperty(this.propertyservice.pgproperty)
          .subscribe(data =>
          {
            this.result=data.toString();
            console.log(data);
          });
          this.router.navigateByUrl('rent-home');
          
        }
    
  }
  resetForm(form : NgForm)
  {
        if(form! =null)
          form.reset();
        this.propertyservice.pgproperty.Advance=0;
        this.propertyservice.pgproperty.Price=0;
           
  }

  backForm(form : NgForm)
  {
    this.router.navigateByUrl('/rent-home/rent-amenities-additional-features');
  }
}
