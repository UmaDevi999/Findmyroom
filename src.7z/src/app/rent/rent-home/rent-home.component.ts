import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";

@Component({
  selector: 'app-rent-home',
  templateUrl: './rent-home.component.html',
  styleUrls: ['./rent-home.component.css'],
  //providers : [PropertyService]

})
export class RentHomeComponent implements OnInit {

  constructor(public propertyservice : PropertyService) { }

  ngOnInit() {
  }

}
