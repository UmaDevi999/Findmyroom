import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentPropertyDetailsComponent } from './rent-property-details.component';

describe('RentPropertyDetailsComponent', () => {
  let component: RentPropertyDetailsComponent;
  let fixture: ComponentFixture<RentPropertyDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentPropertyDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentPropertyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
