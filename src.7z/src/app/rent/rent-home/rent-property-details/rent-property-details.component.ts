import { Component, OnInit } from '@angular/core';
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { PropertyService } from "src/app/property.service";

@Component({
  selector: 'app-rent-property-details',
  templateUrl: './rent-property-details.component.html',
  styleUrls: ['./rent-property-details.component.css'],
  providers: []
})
export class RentPropertyDetailsComponent implements OnInit {

  url: any;
  constructor(public propertyservice: PropertyService,private router:Router) { 
  
  }

  ngOnInit() {
  
  } 
  
  submitForm(form : NgForm)
  { 
      console.log(this.propertyservice.pgproperty.location);
      console.log(this.propertyservice.pgproperty.Flat_type);    

      this.propertyservice.pgproperty.Address=this.propertyservice.streetAdd1+','+this.propertyservice.streetAdd2+','+this.propertyservice.postalcode; 
      
  this.router.navigateByUrl('rent-home/rent-amenities-additional-features');
    
  };
  backForm(form : NgForm)
  { 
      

  this.router.navigateByUrl('rent-home/rent-location');
    
  };
  resetform(form : NgForm)
  {
        if(form! =null)
          form.reset();
        this.propertyservice.streetAdd1="";
        this.propertyservice.streetAdd2="";
        this.propertyservice.postalcode="";
        this.propertyservice.pgproperty.Property_description="";
        this.propertyservice.pgproperty.Built_up_area=0;   
  }

}
