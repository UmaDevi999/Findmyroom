import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { Router }          from '@angular/router'
import { NgForm } from "@angular/forms";



@Component({
  selector: 'app-rent-location',
  templateUrl: './rent-location.component.html',
  styleUrls: ['./rent-location.component.css']
})
export class RentLocationComponent implements OnInit {

  
  constructor(private propertyservice: PropertyService,private router :Router) { }

  ngOnInit() {
    console.log(this.propertyservice.pgproperty)
  }
  submitForm(form : NgForm)
  {
  
  //this
  this.router.navigateByUrl('/rent-home/rent-property-details');
 // this.router.navigate(['/','rent-home','rent-property-details',{nform : form}]);
   // console.log(form.value.city);
    console.log(this.propertyservice.pgproperty.location);
  };
  
}
