import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";

@Component({
  selector: 'app-rent-amenities-additional-features',
  templateUrl: './rent-amenities-additional-features.component.html',
  styleUrls: ['./rent-amenities-additional-features.component.css']
})
export class RentAmenitiesAdditionalFeaturesComponent implements OnInit {

  constructor(public propertyservice:PropertyService, private router : Router) { }

  ngOnInit() {
  }
  
  submitForm(form : NgForm)
  {
    if(this.propertyservice.pgproperty.Sofa == true){
      console.log(this.propertyservice.pgproperty.Sofa);
    }
    else
     {console.log('kajshdjksa');} 
  
  this.router.navigateByUrl('rent-home/rent-pricing');
    
  };
  backForm(form : NgForm)
  {
    
  this.router.navigateByUrl('rent-home/rent-property-details');
    
  };
  
  resetForm(form : NgForm)
  {
        if(form! =null)
          form.reset();
        this.propertyservice.pgproperty.additionalTextArea="";
       // this.propertyservice.pgproperty.rentAmount=0;
           
  }


}
