import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentAmenitiesAdditionalFeaturesComponent } from './rent-amenities-additional-features.component';

describe('RentAmenitiesAdditionalFeaturesComponent', () => {
  let component: RentAmenitiesAdditionalFeaturesComponent;
  let fixture: ComponentFixture<RentAmenitiesAdditionalFeaturesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentAmenitiesAdditionalFeaturesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentAmenitiesAdditionalFeaturesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
