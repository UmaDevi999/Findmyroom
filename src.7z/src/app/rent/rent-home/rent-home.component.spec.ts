import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentHomeComponent } from './rent-home.component';

describe('RentHomeComponent', () => {
  let component: RentHomeComponent;
  let fixture: ComponentFixture<RentHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
