import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RentLocationComponent } from "src/app/rent/rent-home/rent-location/rent-location.component";
import { RentPropertyDetailsComponent } from "src/app/rent/rent-home/rent-property-details/rent-property-details.component";
import { RentAmenitiesAdditionalFeaturesComponent } from "src/app/rent/rent-home/rent-amenities-additional-features/rent-amenities-additional-features.component";
import { RentPricingComponent } from "src/app/rent/rent-home/rent-pricing/rent-pricing.component";
import { RentOwnerDetailsComponent } from "src/app/rent/rent-home/rent-owner-details/rent-owner-details.component";

const routes: Routes = [
  {path:'rent-location',component:RentLocationComponent},
  {path:'rent-property-details',component:RentPropertyDetailsComponent},
  {path:'rent-amenities-additional-features',component:RentAmenitiesAdditionalFeaturesComponent},
  {path:'rent-pricing',component:RentPricingComponent},
  {path:'rent-owner-details',component:RentOwnerDetailsComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RentRoutingModule { }
