import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeOTPComponent } from './change-otp.component';

describe('ChangeOTPComponent', () => {
  let component: ChangeOTPComponent;
  let fixture: ComponentFixture<ChangeOTPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeOTPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeOTPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
