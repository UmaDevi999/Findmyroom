import { Component, OnInit } from '@angular/core';
import { MailServiceService } from "src/app/shared/mail-service.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-change-otp',
  templateUrl: './change-otp.component.html',
  styleUrls: ['./change-otp.component.css']
})
export class ChangeOTPComponent implements OnInit {
  
  newPasword:string;
  confirmNew:string;
  otpGen:string;
  otpField=false;
  otpError=false;
  fieldDisable=true;
  buttonDisable=true;
  smallValue1=true;
  smallValue2=true;
  updateResult=true;
  result:string;
  constructor(private ss:MailServiceService,private router:Router) { }

  ngOnInit() {
  }
  verifyOTP()
  {
      if(this.otpGen==this.ss.otp)
      {
        this.fieldDisable=false;
        this.smallValue1=false;
        this.smallValue2=true;
        this.otpField=true;
        this.otpError=true;
        console.log("done!!");
      }
      else
      {
        this.smallValue1=true;
        this.smallValue2=false;
      }
      
  }
  checkPasswords()
  {
    if(this.newPasword==this.confirmNew)
        this.buttonDisable=false;
  }
  updatePassword()
  {
    if(this.newPasword==this.confirmNew)
      this.ss.updatePassword(this.newPasword).subscribe(data => {
        this.result = data.toString();
        console.log(data);
        if(this.result=='1' || this.result=='0')
          this.updateResult=false;
        else
        {
          this.router.navigateByUrl('/bad-request');
        }
      });
    else
      console.log(" no match");
    
  }
  
}
