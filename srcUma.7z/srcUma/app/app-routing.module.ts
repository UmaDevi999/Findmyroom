import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChangeOTPComponent } from "src/app/change-otp/change-otp.component";
import { ChangeComponent } from "src/app/change/change.component";
import { BadRequestComponent } from "src/app/bad-request/bad-request.component";

const routes: Routes =[
  {path:'change-otp',component:ChangeOTPComponent},
  {path:'change',component:ChangeComponent},
  {path:'bad-request',component:BadRequestComponent}
]


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
