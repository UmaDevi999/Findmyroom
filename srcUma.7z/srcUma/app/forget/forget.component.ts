import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import { MailServiceService } from "src/app/shared/mail-service.service";
import {Router} from "@angular/router";
@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css'],
  
})
export class ForgetComponent implements OnInit {
 
  result:number;
  emailID:string;
  
  constructor(private ss:MailServiceService, private router:Router) { }
  
  ngOnInit() {
  }
  verifyMail()
  {
    // console.log("hello");
    this.ss.verifyEmail(this.emailID).subscribe(data => {
      this.result = data;
      console.log(data);
      if(this.result==1)
        {
          this.ss.emailIDServi=this.emailID;
          this.ss.generateOTPServ(this.emailID).subscribe(data => {
            this.ss.otp = data;
            console.log(this.ss.otp);
            console.log(data);
          });
          this.router.navigateByUrl('/change-otp');
        }
    });
    
  }
}
