import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { ForgetComponent } from './forget/forget.component';
import { ChangeComponent } from './change/change.component';
import { ChangeOTPComponent } from './change-otp/change-otp.component';
import { HttpModule } from "@angular/http";
import { MailServiceService } from "src/app/shared/mail-service.service";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule,Router } from "@angular/router";
import { Routes } from "@angular/router";
import { AppRoutingModule } from "src/app/app-routing.module";
import { BadRequestComponent } from "src/app/bad-request/bad-request.component";


@NgModule({
  declarations: [
    AppComponent,
    ForgetComponent,
    ChangeComponent,
    ChangeOTPComponent,
    BadRequestComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    HttpModule,
    HttpClientModule,
    AppRoutingModule
   
  ],
  exports:[
    
  ],

  providers: [MailServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
