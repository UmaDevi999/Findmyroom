import { Component } from '@angular/core';
import { MailServiceService } from "src/app/shared/mail-service.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[MailServiceService]
})
export class AppComponent {
  title = 'Projectuser';
}
