import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class MailServiceService {

  result:number;
  otp:string;
  emailIDServi:string;
  message:string;
  constructor(private http:HttpClient) { }

  verifyEmail(m:string) : Observable<any> 
  {
    return this.http.get('http://localhost:59207/api/Users/verifyMail?mail='+m);
  }
  generateOTPServ(m:string) : Observable<any> 
  {
    console.log(m);
    return this.http.get('http://localhost:59207/api/Users/generateOTP?mail='+m);
  }
  updatePassword(password:string)
  {
    this.message=this.emailIDServi+':'+password;
    return this.http.get('http://localhost:59207/api/Users/updatePassword?parameter='+this.message);
    
  }
  confirmPassword(oldPassword:string) : Observable<any> 
  {
    this.message=this.emailIDServi+':'+oldPassword;
    return this.http.get('http://localhost:59207/api/Users/confirmPassword?parameter='+this.message);
  }
}
