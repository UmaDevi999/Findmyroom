import { Component, OnInit } from '@angular/core';
import { MailServiceService } from "src/app/shared/mail-service.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-change',
  templateUrl: './change.component.html',
  styleUrls: ['./change.component.css']
})
export class ChangeComponent implements OnInit {

  fieldDisable=true;
  newPasword:string;
  confirmNew:string;
  oldPasword:string;
  buttonDisable=true;
  smallValue1=true;
  smallValue2=true;
  updateResult=true;
  oldField=true;
  result:string;
  constructor(private ss:MailServiceService,private router:Router) { }

  ngOnInit() {
  }
  checkPasswords()
  {
    if(this.newPasword==this.confirmNew)
        this.buttonDisable=false;
  }

  confirmChangePassword()
  {
    //this.Password=this.oldPasword+":"+this.newPasword
    this.ss.confirmPassword(this.oldPasword).subscribe(data => {
      this.result = data.toString();
      if(this.result=='1')
        {
          this.fieldDisable=false;
          this.oldField=true;
        }
        
      else
        this.oldField=false;
      
    });
  }
  
  updatePassword()
  {
    if(this.newPasword==this.confirmNew )
      this.ss.updatePassword(this.newPasword).subscribe(data => {
        this.result = data.toString();
        console.log(data);
        if(this.result=='1')
          this.updateResult=false;
        else
          {
            this.router.navigateByUrl('/bad-request');
          }
      });
    else
      console.log(" no match");
    
  }
}
