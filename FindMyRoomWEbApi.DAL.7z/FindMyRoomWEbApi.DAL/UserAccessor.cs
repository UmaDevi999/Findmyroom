﻿using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.DAL
{
    public class UserAccessor
    {
        private readonly FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();
        public async Task<int> verifyMailDAL(string mail)
        {
            int result = (from t in db.Users
                          where t.email ==mail
                          select t).Count();

            if (result==1)
            {
                return 1;
            }
            return 0;
        }
        public async Task<int> updatePasswordDAL(string mail,string newPassword)
        {
            int result=0;
            User query =(from us in db.Users
                       where us.email == mail
                       select us).SingleOrDefault();
            query.password = newPassword;
            try
            {
                result= await db.SaveChangesAsync();
            }
            catch(Exception e)
            {
                throw new Exception(e.Message);
            }
            return result;
        }
        public async Task<string> confirmPasswordDAL(string mail)
        {
            int result = 0;
            User query = (from us in db.Users
                          where us.email == mail
                          select us).SingleOrDefault();
            return query.password;
        }
    }
}
