﻿using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindMyRoomWEbApi.DAL
{
    public class PropertyAccessor
    {
        private readonly FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();

        public async Task<int> PostPropertyDAL(PropertyRegistration propertyRegistration)
        {
            int result = db.INSERT_PROPERTY(propertyRegistration.Property_Name, propertyRegistration.Address, propertyRegistration.Advance, propertyRegistration.Amenities, propertyRegistration.Carpet_area, propertyRegistration.Construction_Age, propertyRegistration.isVerified, propertyRegistration.locationId, propertyRegistration.no_of_floors, propertyRegistration.Posted_date, propertyRegistration.Price, propertyRegistration.Property_description, propertyRegistration.Type, propertyRegistration.UserId, propertyRegistration.Occupancy, propertyRegistration.AvailableFor, propertyRegistration.Bachelor_friendly, propertyRegistration.Built_up_area, propertyRegistration.Deal_type, propertyRegistration.Flat_type, propertyRegistration.Flooring, propertyRegistration.Furnishing, propertyRegistration.Possesion_ready, propertyRegistration.water_source, propertyRegistration.AC, propertyRegistration.Bed, propertyRegistration.Community_hall, propertyRegistration.Gas_conn, propertyRegistration.Lift, propertyRegistration.Parking, propertyRegistration.Refridgerator, propertyRegistration.Sofa, propertyRegistration.swimming_pool, propertyRegistration.TV);
            return result;
        }

        public async Task<int> UpdatePropertyDAL(PropertyUpdation propertyUpdation)
        {
            int result=db.Update_PROPERTY(propertyUpdation.PropertyID, propertyUpdation.Property_Name, propertyUpdation.Address, propertyUpdation.Advance, propertyUpdation.Amenities, propertyUpdation.Carpet_area, propertyUpdation.Construction_Age, propertyUpdation.isVerified, propertyUpdation.locationId, propertyUpdation.no_of_floors, propertyUpdation.Posted_date, propertyUpdation.Price, propertyUpdation.Property_description, propertyUpdation.Type, propertyUpdation.UserId, propertyUpdation.Occupancy, propertyUpdation.AvailableFor, propertyUpdation.Bachelor_friendly, propertyUpdation.Built_up_area, propertyUpdation.Deal_type, propertyUpdation.Flat_type, propertyUpdation.Flooring, propertyUpdation.Furnishing, propertyUpdation.Possesion_ready, propertyUpdation.water_source, propertyUpdation.AC, propertyUpdation.Bed, propertyUpdation.Community_hall, propertyUpdation.Gas_conn, propertyUpdation.Lift, propertyUpdation.Parking, propertyUpdation.Refridgerator, propertyUpdation.Sofa, propertyUpdation.swimming_pool, propertyUpdation.TV);
            return result;

        }
        public List<User_PropertyDetails_Result> GetPropertyDAL(int PropId)
        {
            List<User_PropertyDetails_Result> listprops = db.User_PropertyDetails(PropId).ToList<User_PropertyDetails_Result>();
            return listprops;
        }

    }
}

