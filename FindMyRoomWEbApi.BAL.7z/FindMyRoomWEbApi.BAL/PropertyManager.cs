﻿using FindMyRoomWEbApi.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FindMyRoomWEbApi.DAL;
using System.Data.Entity.Core.Objects;

namespace FindMyRoomWEbApi.BAL
{
    public class PropertyManager
    {
        readonly PropertyAccessor propertyAccessor = new PropertyAccessor();

        public async Task<int> PostPropertyBAL(PropertyRegistration propertyRegistration)
        {
            return await propertyAccessor.PostPropertyDAL(propertyRegistration);
        }
        public async Task<int> UpdatePropertyBAL(PropertyUpdation details)
        {
            return await propertyAccessor.UpdatePropertyDAL(details);
        }
        public List<User_PropertyDetails_Result> GetPropertyBAL(int id)
        {
            return  propertyAccessor.GetPropertyDAL(id);
        }
    }
}
