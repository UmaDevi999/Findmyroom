﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FindMyRoomWEbApi.Entity;

namespace FindMyRoomWEbApi.Controllers
{
    public class FeedbackTablesController : ApiController
    {
        private readonly FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();

        // GET: api/FeedbackTables
        public IQueryable<FeedbackTable> GetFeedbackTables()
        {
            return db.FeedbackTables;
        }

        // GET: api/FeedbackTables/5
        [ResponseType(typeof(FeedbackTable))]
        public async Task<IHttpActionResult> GetFeedbackTable(int id)
        {
            FeedbackTable feedbackTable = await db.FeedbackTables.FindAsync(id);
            if (feedbackTable == null)
            {
                return NotFound();
            }

            return Ok(feedbackTable);
        }

        // PUT: api/FeedbackTables/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutFeedbackTable(int id, FeedbackTable feedbackTable)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != feedbackTable.FeedBackId)
            {
                return BadRequest();
            }

            db.Entry(feedbackTable).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FeedbackTableExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/FeedbackTables
        [ResponseType(typeof(FeedbackTable))]
        public async Task<IHttpActionResult> PostFeedbackTable(FeedbackTable feedbackTable)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.FeedbackTables.Add(feedbackTable);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = feedbackTable.FeedBackId }, feedbackTable);
        }

        // DELETE: api/FeedbackTables/5
        [ResponseType(typeof(FeedbackTable))]
        public async Task<IHttpActionResult> DeleteFeedbackTable(int id)
        {
            FeedbackTable feedbackTable = await db.FeedbackTables.FindAsync(id);
            if (feedbackTable == null)
            {
                return NotFound();
            }

            db.FeedbackTables.Remove(feedbackTable);
            await db.SaveChangesAsync();

            return Ok(feedbackTable);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool FeedbackTableExists(int id)
        {
            return db.FeedbackTables.Count(e => e.FeedBackId == id) > 0;
        }
    }
}