﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using FindMyRoomWEbApi.BAL;
using FindMyRoomWEbApi.Entity;

namespace FindMyRoomWEbApi.Controllers
{
    public class PropertiesController : ApiController
    {
        PropertyManager propertyManager = new BAL.PropertyManager();
        [HttpPost]
        public async Task<int> PostProperty([FromBody] PropertyRegistration propertyRegistration)
        {
            return await propertyManager.PostPropertyBAL(propertyRegistration);
        }
        [HttpPut]
        public async Task<int> UpdateProperty(PropertyUpdation details)
        {
            return await propertyManager.UpdatePropertyBAL(details);
        }
        [HttpGet]
        public List<User_PropertyDetails_Result> GetProperty(int id)
        {
           List<User_PropertyDetails_Result> x =  propertyManager.GetPropertyBAL(id);
            return x;
        }
    }
}
