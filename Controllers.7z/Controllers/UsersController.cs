﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using FindMyRoomWEbApi.BAL;
using FindMyRoomWEbApi.Entity;


namespace FindMyRoomWEbApi.Controllers
{
    public class UsersController : ApiController
    {
        
        private string userMailId;
        private FindMyRoom_DatabaseEntities db = new FindMyRoom_DatabaseEntities();
        UserManager um = new UserManager();

        // GET: api/Users
        public IEnumerable<User> GetUsers()
        {
            return db.Users;
        }
        [HttpGet]
        [Route("api/Users/verifyMail/")]
        public async Task<int> verifyMail(string mail)
        {
            userMailId = mail;
            return await um.verifyMailBAL(mail);
            //if (c == 1)
            //    um.generateOTPBAL(userMailId);
            //return c;
        }

        [HttpGet]
        [Route("api/Users/generateOTP")]
        public async Task<string> generateOTP(string mail)
        {
            return await um.generateOTPBAL(mail);
        }

        [HttpGet]
        [Route("api/Users/updatePassword")]
        public async Task<int> updatePassword(string parameter)
        {
            string[] values = parameter.Split(':');
            try
            {
                return await um.updatePasswordBAL(values[0], values[1]);
            }
            catch(Exception e)
            {
                return -1;
            }
            
        }

        [HttpGet]
        [Route("api/Users/confirmPassword")]
        public async Task<int> confirmPassword(string parameter)
        {
            string[] values = parameter.Split(':');
            return await um.confirmPasswordBAL(values[0], values[1]);
        }


        // GET: api/Users/5
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> GetUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        // PUT: api/Users/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutUser(int id, User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != user.UserId)
            {
                return BadRequest();
            }

            db.Entry(user).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Users
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> PostUser(User user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Users.Add(user);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = user.UserId }, user);
        }

        // DELETE: api/Users/5
        [ResponseType(typeof(User))]
        public async Task<IHttpActionResult> DeleteUser(int id)
        {
            User user = await db.Users.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            db.Users.Remove(user);
            await db.SaveChangesAsync();

            return Ok(user);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool UserExists(int id)
        {
            return db.Users.Count(e => e.UserId == id) > 0;
        }
    }
}