import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SaleRoutingModule } from './sale-routing.module';
import { SaleHomeComponent } from './sale-home/sale-home.component';
import { SaleLocationComponent } from "src/app/sale/sale-home/sale-location/sale-location.component";
import { SalePropertyDetailsComponent } from "src/app/sale/sale-home/sale-property-details/sale-property-details.component";
import { SaleOwnerDetailsComponent } from "src/app/sale/sale-home/sale-owner-details/sale-owner-details.component";
import { SalePricingComponent } from "src/app/sale/sale-home/sale-pricing/sale-pricing.component";
import { SaleAmenitiesAdditionalFeaturesComponent } from "src/app/sale/sale-home/sale-amenities-additional-features/sale-amenities-additional-features.component";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

@NgModule({
  imports: [
    CommonModule,
    SaleRoutingModule,
    FormsModule,
    BrowserModule
  ],
  declarations: [SaleLocationComponent, SalePropertyDetailsComponent, SaleOwnerDetailsComponent, SalePricingComponent, SaleAmenitiesAdditionalFeaturesComponent, SaleHomeComponent]
})
export class SaleModule { }
