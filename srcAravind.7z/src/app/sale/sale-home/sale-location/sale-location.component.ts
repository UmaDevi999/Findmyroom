import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";

@Component({
  selector: 'app-sale-location',
  templateUrl: './sale-location.component.html',
  styleUrls: ['./sale-location.component.css']
})
export class SaleLocationComponent implements OnInit {

   
  constructor(private propertyservice: PropertyService,private router :Router) { }
  
    ngOnInit() {
    }
    submitForm(form : NgForm)
    {
    
    //this
    this.router.navigateByUrl('/sale-home/sale-property-details');
   // this.router.navigate(['/','rent-home','rent-property-details',{nform : form}]);
     // console.log(form.value.city);
      console.log(this.propertyservice.pgproperty.location);
    };
}
