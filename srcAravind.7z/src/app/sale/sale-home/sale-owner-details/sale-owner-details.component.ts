import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-owner-details',
  templateUrl: './sale-owner-details.component.html',
  styleUrls: ['./sale-owner-details.component.css']
})
export class SaleOwnerDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
