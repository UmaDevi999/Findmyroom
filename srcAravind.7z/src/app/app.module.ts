import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RentModule } from "src/app/rent/rent.module";
import { PgModule } from "src/app/pg/pg.module";
import { SaleModule } from "src/app/sale/sale.module";
import { HttpClientModule } from "@angular/common/http";
import { DummyEditComponent } from './dummy-edit/dummy-edit.component';
import { PropertyService } from "src/app/property.service";

@NgModule({
  declarations: [
    AppComponent,
    DummyEditComponent
  ],
  imports: [
    BrowserModule,
    RentModule,
    SaleModule,
    PgModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [PropertyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
