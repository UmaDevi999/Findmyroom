import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";
import { PropertyService } from "src/app/property.service";

@Component({
  selector: 'app-rent-owner-details',
  templateUrl: './rent-owner-details.component.html',
  styleUrls: ['./rent-owner-details.component.css']
})
export class RentOwnerDetailsComponent implements OnInit {

  url: any;
  constructor(public propertyservice : PropertyService,private router : Router) { }

  ngOnInit() {
  }
  readUrl(event:any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.onload = (event: ProgressEvent) => {
        this.url = (<FileReader>event.target).result;
      }
  
      reader.readAsDataURL(event.target.files[0]);
    }
  }

  submitForm(form : NgForm)
  {
  //this
  this.router.navigateByUrl('/rent-home/rent-owner-details');
 // this.router.navigate(['/','rent-home','rent-property-details',{nform : form}]);
  };
  backForm(form : NgForm)
  {
  //this
  this.router.navigateByUrl('/rent-home/rent-location');
 // this.router.navigate(['/','rent-home','rent-property-details',{nform : form}]);
  };

}
