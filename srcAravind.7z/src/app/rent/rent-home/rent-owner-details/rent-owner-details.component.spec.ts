import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentOwnerDetailsComponent } from './rent-owner-details.component';

describe('RentOwnerDetailsComponent', () => {
  let component: RentOwnerDetailsComponent;
  let fixture: ComponentFixture<RentOwnerDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentOwnerDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentOwnerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
