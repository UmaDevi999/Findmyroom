import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RentLocationComponent } from './rent-location.component';

describe('RentLocationComponent', () => {
  let component: RentLocationComponent;
  let fixture: ComponentFixture<RentLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RentLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RentLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
