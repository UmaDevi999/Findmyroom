import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RentRoutingModule } from './rent-routing.module';

import { RentHomeComponent } from './rent-home/rent-home.component';
import { RentAmenitiesAdditionalFeaturesComponent } from "src/app/rent/rent-home/rent-amenities-additional-features/rent-amenities-additional-features.component";
import { RentPricingComponent } from "src/app/rent/rent-home/rent-pricing/rent-pricing.component";
import { RentOwnerDetailsComponent } from "src/app/rent/rent-home/rent-owner-details/rent-owner-details.component";
import { RentPropertyDetailsComponent } from "src/app/rent/rent-home/rent-property-details/rent-property-details.component";
import { RentLocationComponent } from "src/app/rent/rent-home/rent-location/rent-location.component";
import { FormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";

@NgModule({
  imports: [
    CommonModule,
    RentRoutingModule,
    FormsModule,
    BrowserModule
  ],
  declarations: [RentAmenitiesAdditionalFeaturesComponent, RentPricingComponent, RentOwnerDetailsComponent, RentPropertyDetailsComponent, RentHomeComponent, RentLocationComponent]
})
export class RentModule { }
