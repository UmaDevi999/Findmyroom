import { Injectable } from '@angular/core';
import { Pgpropertydet } from "src/app/pgpropertydet";
import { Http, Response, Headers, RequestMethod, RequestOptions} from '@angular/http';
import {map} from 'rxjs/operators';
import { NgForm } from "@angular/forms";
import { HttpClient } from "@angular/common/http";
import { HttpHeaders } from "@angular/common/http";
import { PropertyUpdateDetails } from "src/app/PropertyUpdateDetails";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class PropertyService {

  public streetAdd1:string;
  public streetAdd2:string;
  public postalcode:string;
  public propId:number;
  

pgproperty = new Pgpropertydet();
propertyDetails=new PropertyUpdateDetails();

  constructor(private http : HttpClient) { }

  GetProperty() :Observable<any>
  {
    return this.http.get('http://localhost:59207/api/Properties/1');
    
  }
  PostProperty(propertyDetails :Pgpropertydet)
  {
    
    var body = JSON.stringify(propertyDetails);
     
    let headerOption:HttpHeaders=new HttpHeaders()
    .set('Content-Type','application/json')
    .set('Access-Control-Allow-Origin','http://localhost:4200');
     return this.http.post('http://localhost:59207/api/Properties/PostProperty/',body,{headers:headerOption});
  }

  PutProperty(propertyDetails :Pgpropertydet)
  {
    this.propertyDetails.PropertyID=1;
    //console.log(this.propertyDetails.PropertyID);
    var body = JSON.stringify(propertyDetails);
     
    let headerOption:HttpHeaders=new HttpHeaders()
    .set('Content-Type','application/json')
    .set('Access-Control-Allow-Origin','http://localhost:4200');
     return this.http.put('http://localhost:59207/api/Properties/PutProperty/',body,{headers:headerOption});
  }
}
