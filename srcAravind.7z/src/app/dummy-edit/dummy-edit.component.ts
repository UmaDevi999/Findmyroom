import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";
import { Router } from "@angular/router";
import { Observable } from "rxjs";
import { Pgpropertydet } from "src/app/pgpropertydet";

@Component({
  selector: 'app-dummy-edit',
  templateUrl: './dummy-edit.component.html',
  styleUrls: ['./dummy-edit.component.css']
})
export class DummyEditComponent implements OnInit {
  propertylist = new Array<Pgpropertydet>();
  constructor(private propertyService:PropertyService,private router:Router) { }

  ngOnInit() {
  
   
  }

  EditProperty(id:number)
  {
    this.propertyService.GetProperty()
    .subscribe(data  => {
      this.propertyService.pgproperty = data as Pgpropertydet
      //this.propertyService.pgproperty.PropertyID = 1;
      this.propertyService.propId=1;
      //console.log(this.propertyService.pgproperty)
      this.router.navigateByUrl('/rent-location');
    })
      
  }

}
