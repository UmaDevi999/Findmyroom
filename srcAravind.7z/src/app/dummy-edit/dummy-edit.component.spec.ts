import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DummyEditComponent } from './dummy-edit.component';

describe('DummyEditComponent', () => {
  let component: DummyEditComponent;
  let fixture: ComponentFixture<DummyEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DummyEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DummyEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
