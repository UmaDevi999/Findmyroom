import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PgPricingComponent } from './pg-pricing.component';

describe('PgPricingComponent', () => {
  let component: PgPricingComponent;
  let fixture: ComponentFixture<PgPricingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PgPricingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PgPricingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
