import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PgPropertyDetailsComponent } from './pg-property-details.component';

describe('PgPropertyDetailsComponent', () => {
  let component: PgPropertyDetailsComponent;
  let fixture: ComponentFixture<PgPropertyDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PgPropertyDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PgPropertyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
