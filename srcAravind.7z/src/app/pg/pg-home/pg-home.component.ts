import { Component, OnInit } from '@angular/core';
import { PropertyService } from "src/app/property.service";


@Component({
  selector: 'app-pg-home',
  templateUrl: './pg-home.component.html',
  styleUrls: ['./pg-home.component.css'],
  providers:[PropertyService]
})
export class PgHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
