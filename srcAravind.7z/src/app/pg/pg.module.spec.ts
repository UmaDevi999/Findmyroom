import { PgModule } from './pg.module';

describe('PgModule', () => {
  let pgModule: PgModule;

  beforeEach(() => {
    pgModule = new PgModule();
  });

  it('should create an instance', () => {
    expect(pgModule).toBeTruthy();
  });
});
