import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PgRoutingModule } from './pg-routing.module';
import { PgHomeComponent } from './pg-home/pg-home.component';
import { PgLocationComponent } from "src/app/pg/pg-home/pg-location/pg-location.component";
import { PgPropertyDetailsComponent } from "src/app/pg/pg-home/pg-property-details/pg-property-details.component";
import { PgOwnerDetailsComponent } from "src/app/pg/pg-home/pg-owner-details/pg-owner-details.component";
import { PgPricingComponent } from "src/app/pg/pg-home/pg-pricing/pg-pricing.component";
import { PgAmenitiesAdditionalFeaturesComponent } from "src/app/pg/pg-home/pg-amenities-additional-features/pg-amenities-additional-features.component";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from "@angular/forms";

@NgModule({
  imports: [
    CommonModule,
    PgRoutingModule,
    FormsModule,
    BrowserModule
  ],
  declarations: [PgHomeComponent, PgLocationComponent, PgPropertyDetailsComponent, PgOwnerDetailsComponent, PgPricingComponent, PgAmenitiesAdditionalFeaturesComponent]
})
export class PgModule { }
