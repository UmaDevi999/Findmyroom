import { Component } from '@angular/core';
import { PropertyService } from "src/app/property.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [PropertyService],
})
export class AppComponent {
  title = 'projectfinal';
}
