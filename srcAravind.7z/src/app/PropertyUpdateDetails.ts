export class PropertyUpdateDetails {
    public PropertyID:number;
    public Property_Name :  string;
    public Amenities : boolean;
    public Carpet_area : number;
    public Posted_date : string;
    public isVerified : boolean;
    public city : number;//3
    public UserId : string;
    public Type : string;
    public location: number;//3//LocationId
    public Built_up_area : number;//rent-sale
    public Construction_Age : number;//3
    public no_of_floors : number;//3
    public Flooring: string;//rent-sale
    public water_source :string;//rent-sale
    public Flat_type : string;//rent-sale
    public Sofa: boolean;//3
    public Property_description : string;//3
    public Address : string;//3
    public Furnishing : boolean;
    public Deal_type : string;//renttype//rent-sale
    public Possesion_ready : boolean;//rent-sale
    public Bachelor_friendly : boolean;//sale-rent
    public TV : boolean;//3
    public Refridgerator : boolean;//3
    public AC : boolean;//3
    public Bed : boolean;//3
    public Gas_conn : boolean;//3
    public swimming_pool : boolean;//3
    public Community_hall : boolean;//3
    public Lift : boolean;//3
    public Parking : boolean;//rent-sale
    public additionalTextArea : string;
    public Advance : number;//3
    public Price : number;//expectedAmount,3
    public Occupancy : number;//pg
    public AvailableFor : boolean;//pg

    
}
